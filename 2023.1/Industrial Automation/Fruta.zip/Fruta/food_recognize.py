import io
import os
from datetime import datetime

import cv2
from google.cloud import vision_v1p3beta1 as vision

os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'client_key.json'

SOURCE_PATH = os.getcwd() + "/images/"
print(SOURCE_PATH)

FOOD_TYPE = 'Fruit'  


def load_food_name(food_type):
    names = [line.rstrip('\n').lower() for line in open('dict/' + food_type + '.dict')]
    return names


def recognize_food(img_path, list_foods):
    start_time = datetime.now()

    img = cv2.imread(img_path)

    height, width = img.shape[:2]

    img = cv2.resize(img, (800, int((height * 800) / width)))

    cv2.imwrite(SOURCE_PATH + "/output.jpg", img)

    img_path = SOURCE_PATH + "/output.jpg"

    client = vision.ImageAnnotatorClient()

    with io.open(img_path, 'rb') as image_file:
        content = image_file.read()

    image = vision.types.Image(content=content)

    response = client.label_detection(image=image)
    labels = response.label_annotations

    for label in labels:
        desc = label.description.lower()
        score = round(label.score, 2)
        print("label: ", desc, "  score: ", score)
        if (desc in list_foods):
            cv2.putText(img, desc.upper(), (300, 150), cv2.FONT_HERSHEY_SIMPLEX, 1, (50, 50, 200), 2)
            cv2.imshow('Recognize & Draw', img)
            cv2.waitKey(0)

            break

    print('Total time: {}'.format(datetime.now() - start_time))


print('---------- Start FOOD Recognition --------')
list_foods = load_food_name(FOOD_TYPE)
path = SOURCE_PATH + '1.jpg'
recognize_food(path, list_foods)
print('---------- End ----------')
